
const state = {
  nav: []
}
const mutations = {
  setNav (state, payload) {
    state.nav = payload
  }
}
const actions = {

}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
