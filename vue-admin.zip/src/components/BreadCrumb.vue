<template>
  <el-breadcrumb separator-class="el-icon-arrow-right">
    <el-breadcrumb-item :to="{ path: '/home' }">首页</el-breadcrumb-item>
    <el-breadcrumb-item
      v-for="(item, index) in $store.getters.nav"
      :key="index"
      >{{ item }}</el-breadcrumb-item
    >
  </el-breadcrumb>
</template>

<script>
export default {

  created () {
  },
  data () {
    return {

    }
  },
  methods: {
  },
  computed: {},
  watch: {
  },
  filters: {},
  components: {}
}
</script>

<style scoped>
</style>
