import { getGoodsList } from '@/api/goods'
const state = {
  pagenum: 1, // 当前页码
  pagesize: 5, // 每页显示条数
  goods: [], // 商品列表
  total: 0
}
const mutations = {
  // 设置商品列表
  setGoods (state, payload) {
    state.goods = payload
  },
  // 设置总数
  setTotal (state, payload) {
    state.total = payload
  }
}
const actions = {
  // 获取商品列表
  async getGoodsList (context, params) {
    const res = await getGoodsList(params)
    context.commit('setGoods', res.data.data.goods)
    context.commit('setTotal', res.data.data.total)
    console.log(res)
  }
}
export default {
  namespaced: true,
  state,
  mutations,
  actions
}
